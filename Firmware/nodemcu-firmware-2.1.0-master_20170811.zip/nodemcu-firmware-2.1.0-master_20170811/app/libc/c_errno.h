#ifndef __c_errno_h
#define __c_errno_h

#include <errno.h>
// #ifndef errno
// extern int errno;
// #endif

// #define EDOM    1
// #define ERANGE 	2
// #define EILSEQ  4
// #define ESIGNUM 3
// #define EINVAL  5
// #define ENOMEM  6

#endif

/* end of c_errno.h */

